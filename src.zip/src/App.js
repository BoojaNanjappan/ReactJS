import logo from './logo.svg';
import React, { useRef } from "react";

function App() {
    const inputRef = useRef(null);

    function handleSubmit() {
        alert(Name: $ { inputRef.current.value });
    }

    return ( <
        div >
        <
        h3 > Uncontrolled Component < /h3>

        <
        form onSubmit = { handleSubmit } >
        <
        label > Name: < /label>

        <
        input type = "text"
        name = "name"
        ref = { inputRef }
        />

        <
        button type = "submit" > Submit < /button> <
        /form> <
        /div>
    );
}

export  default  App;